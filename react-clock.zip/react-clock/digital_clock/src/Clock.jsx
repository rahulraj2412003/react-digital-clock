import { useState, useEffect } from 'react';
function Clock(){
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setTime(new Date());
        }, 1000);

        return () => clearInterval(timer);
    }, []);


    function formatTime() {
        let hour=time.getHours()
        const minute=time.getMinutes()
        const second=time.getSeconds()
        const meridiem = hour >= 12 ? 'PM' : 'AM';

        hour= hour%12 || 12;

        return `${zeroPad(hour)}:${zeroPad(minute)}:${zeroPad(second)} ${meridiem}`;
    }

    function zeroPad(num) {
        return (num < 10 ? `0${num}` : num);
    }
    return(
        <div className="clock">
            <p>
                <span>{formatTime()}</span>
            </p>
        </div>
    )
}

export default Clock